// main page
function myFunction() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}

// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn1");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
// var popupArray =["myModal", "myModal2","myModal3", "myModal4", "myModal5", "myModal6", "myModal7", "myModal8"]
// window.addEventListener ("mouseup", function(event){

//   for (var i=0; i< popupArray.length; i++){
//   var popup = document.getElementById("myModal");
//   if (event.target!= modal && event.target.parentNode != modal){
//     modal.style.display="none";
//   }
//   }
// })

// modal 2
var modal2 = document.getElementById("myModal2");
var btn2 = document.getElementById("myBtn2");
var span2 = document.getElementsByClassName("close2")[0];
btn2.onclick = function() {
  modal2.style.display = "block";
}
span2.onclick = function() {
  modal2.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == modal2) {
//     modal2.style.display = "none";
//   }
// }

// modal 3
var modal3 = document.getElementById("myModal3");
var btn3 = document.getElementById("myBtn3");
var span3 = document.getElementsByClassName("close3")[0];
btn3.onclick = function() {
  modal3.style.display = "block";
}
span3.onclick = function() {
  modal3.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == modal3) {
//     modal3.style.display = "none";
//   }
// }

// modal 4
var modal4 = document.getElementById("myModal4");
var btn4 = document.getElementById("myBtn4");
var span4 = document.getElementsByClassName("close4")[0];
btn4.onclick = function() {
  modal4.style.display = "block";
}
span4.onclick = function() {
  modal4.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == modal4) {
//     modal4.style.display = "none";
//   }
// }

// modal 5
var modal5 = document.getElementById("myModal5");
var btn5 = document.getElementById("myBtn5");
var span5 = document.getElementsByClassName("close5")[0];
btn5.onclick = function() {
  modal5.style.display = "block";
}
span5.onclick = function() {
  modal5.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == modal5) {
//     modal5.style.display = "none";
//   }
// }

 // modal 6
var modal6 = document.getElementById("myModal6");
var btn6 = document.getElementById("myBtn6");
var span6 = document.getElementsByClassName("close6")[0];
btn6.onclick = function() {
  modal6.style.display = "block";
}
span6.onclick = function() {
  modal6.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == modal6) {
//     modal6.style.display = "none";
//   }
// }

// modal 7
var modal7 = document.getElementById("myModal7");
var btn7 = document.getElementById("myBtn7");
var span7 = document.getElementsByClassName("close7")[0];
btn7.onclick = function() {
  modal7.style.display = "block";
}
span7.onclick = function() {
  modal7.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == modal7) {
//     modal7.style.display = "none";
//   }
// }

// modal 8
var modal8 = document.getElementById("myModal8");
var btn8 = document.getElementById("myBtn8");
var span8 = document.getElementsByClassName("close8")[0];
btn8.onclick = function() {
  modal8.style.display = "block";
}
span8.onclick = function() {
  modal8.style.display = "none";
}
// window.onclick = function(event) {
//   if (event.target == modal8) {
//     modal8.style.display = "none";
//   }
// }
// 
// modal 9
var modal9 = document.getElementById("myModal9");
var btn9 = document.getElementById("myBtn9");
var span9 = document.getElementsByClassName("close9")[0];
btn9.onclick = function() {
  modal9.style.display = "block";
}
span9.onclick = function() {
  modal9.style.display = "none";
}

// modal 10
var modal10 = document.getElementById("myModal10");
var btn10 = document.getElementById("myBtn10");
var span10 = document.getElementsByClassName("close10")[0];
btn10.onclick = function() {
  modal10.style.display = "block";
}
span10.onclick = function() {
  modal10.style.display = "none";
}

// modal 11
var modal11 = document.getElementById("myModal11");
var btn11 = document.getElementById("myBtn11");
var span11 = document.getElementsByClassName("close11")[0];
btn11.onclick = function() {
  modal11.style.display = "block";
}
span11.onclick = function() {
  modal11.style.display = "none";
}

// modal 12
var modal12 = document.getElementById("myModal12");
var btn12 = document.getElementById("myBtn12");
var span12 = document.getElementsByClassName("close12")[0];
btn12.onclick = function() {
  modal12.style.display = "block";
}
span12.onclick = function() {
  modal12.style.display = "none";
}

